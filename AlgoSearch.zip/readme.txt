Olá professor!

- Como executar

Para rodar o arquivo basta apenas ter o GNU/GCC instalado!

Nós fizemos um script em um arquivo .bat para faciliar o "build and run" da aplicação, assim apenas digite no terminal da pasta:

./build_run.bat

- Explicação

1) Todos os arquivos estão com caminhos relativos referentes a pasta, logo não há necessidade de atualziar nenhum caminho dentro do código.
2) Note professor que o arquivo usa tempalte do C++, isso porque estava tentando generalizar a construção de árvore para qualquer tipo
possível dentro de C++, contudo estavamos tendo muita dificuldade com o uso de STL e templates especializados, e acabamos restrinjindo os códigos para apenas tipo string, mesmo usando o template.
3) Note também que usamos heranças e classes dentro de C++, para facilitar a construção de AB -> ABB -> AVL
4) E por fim, verá que usamos as lib de vetores, mapas e sets dentro de C++ para ajudar na construções dos dados estátisticos finais.

Obrigado!


CAIO UEHARA MARTINS N USP 1367202
LUIZ DE SOUZA MURAKAMI N USP 5631500