#ifndef TREE_H
#define TREE_H

// Bibiliotecas padrões
#include <iostream>
#include <string>

// Headers das árvores
#include "./binary_tree.h"
#include "./binary_search_tree.h"
#include "./binary_search_tree_balanced.h"

#endif